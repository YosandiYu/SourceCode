﻿namespace netAPI.Models
{
    public class AccountInquiryBalanceRequest
    {
        public string UserReferenceNumber { get; set; }
        public string RequestTime { get; set; }
        public string AccountNumber { get; set; }
    }
}
