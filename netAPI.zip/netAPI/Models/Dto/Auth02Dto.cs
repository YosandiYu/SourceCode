namespace netAPI.Models.Dto
{
    public class Auth02Dto
    {
        public string OACClientID { get; set; }
        public string OACClientIDSecret { get; set; }
        public string BDIKey { get; set; }
        public string BDIKeySecret { get; set; }
    }
}
