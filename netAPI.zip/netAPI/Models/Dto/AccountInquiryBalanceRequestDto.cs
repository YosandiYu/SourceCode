﻿namespace netAPI.Models.Dto
{
    public class AccountInquiryBalanceRequestDto
    {
        public HeaderDto Header { get; set; }
        public AccountInquiryBalanceRequest AccountInquiryBalanceRequest { get; set; }
    }
}
