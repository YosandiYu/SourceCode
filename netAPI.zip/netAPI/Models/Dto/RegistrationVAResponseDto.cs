﻿namespace netAPI.Models.Dto
{
    public class RegistrationVAResponseDto
    {
        public string UserReferenceNumber { get; set; }
        public string ResponseTime { get; set; }
        public string VirtualAccountNumber { get; set; }
        public string CodeStatus { get; set; }
        public string DescStatus { get; set; }
    }
}
