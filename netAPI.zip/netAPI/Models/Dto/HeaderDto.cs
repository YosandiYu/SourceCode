﻿namespace netAPI.Models.Dto
{
    public class HeaderDto
    {
        public string BDI_Signature { get; set; }
        public string BDI_Key { get; set; }
        public string BDI_Timestamp { get; set; }
        public string Authorization { get;set; }
    }
}
