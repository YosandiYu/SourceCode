﻿using netAPI.Models.Dto;

namespace netAPI.Service.IService
{
    public interface IDanamonService
    {
        Task<ResponseDto?> RegistrationVAAsync(RegistrationVARequestDto registrationVaRequestDto);
        Task<ResponseDto?> AccountInquiryBalanceAsync(AccountInquiryBalanceRequestDto accountInquiryBalanceRequestDto);
        Task<ResponseDto?> GetToken();
    }
}
