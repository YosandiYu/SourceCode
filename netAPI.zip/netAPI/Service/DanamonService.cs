﻿using netAPI.Models.Dto;
using netAPI.Service.IService;
using netAPI.Utility;

namespace netAPI.Service
{
    public class DanamonService: IDanamonService
    {
        private readonly IBaseService _baseService;

        public DanamonService(IBaseService baseService)
        {
            _baseService = baseService;
        }

        public async Task<ResponseDto?> RegistrationVAAsync(RegistrationVARequestDto registvarequestDto)
        {
            return await _baseService.SendAsync(new RequestDto()
            {
                ApiType = SD.ApiType.POST,
                Data = registvarequestDto.registrationVARequest,
                Header = new HeaderDto()
                {
                    BDI_Signature = registvarequestDto.BDISignature,
                    BDI_Key = registvarequestDto.BDIKey,
                    BDI_Timestamp = registvarequestDto.BDITimestamp,
                    Authorization= @"Bearer " + registvarequestDto.Authorization

                },
                Url = SD.RegisterVaAPIBase,
                ContentType = SD.ContentType.Json
            }, false);
        }

        public async Task<ResponseDto?> AccountInquiryBalanceAsync(AccountInquiryBalanceRequestDto accountInquiryBalanceRequestDto)
        {
            return await _baseService.SendAsync(new RequestDto()
            {
                ApiType = SD.ApiType.POST,
                Data = accountInquiryBalanceRequestDto.AccountInquiryBalanceRequest,
                Header = accountInquiryBalanceRequestDto.Header,
                Url = SD.RegisterVaAPIBase,
                ContentType = SD.ContentType.Json
            });
        }

        public async Task<ResponseDto?> GetToken()
        {
            return await _baseService.getToken();
        }
    }
}
